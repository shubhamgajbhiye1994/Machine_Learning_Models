
#Importing the libraries 
from keras.layers import Dropout
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import RandomizedSearchCV,StratifiedKFold


# Importing the dataset
train_dataset = pd.read_csv('train.csv')
catego_col = ['Accident_Type_Code','Violations','Severity']


def preprocessing(dummy_dataset):
    
    #droping the accident_id column
    dataset = dummy_dataset.drop(columns=['Accident_ID'])

    #converting columns into categorical columns
    for i in dataset.columns:
        if i in catego_col:
            dataset[i] = pd.Categorical(dataset[i])
    
    #mapping target into interger values        
    severity_map = {'Highly_Fatal_And_Damaging' : 0 ,'Significant_Damage_And_Serious_Injuries' : 1 ,'Minor_Damage_And_Injuries' : 2,'Significant_Damage_And_Fatalities':3}
    dataset.Severity.replace(to_replace=severity_map,inplace=True)
    
    #defining independent and dependent variable
    x = pd.get_dummies(dataset,columns=['Violations','Accident_Type_Code']) #one hot encoding of categorical variables
    
    if 'Severity' in dataset.columns :
        y = dataset['Severity']
        x = x.drop(columns=['Severity','Violations_5','Accident_Type_Code_7'])
    else:
        y = None
        x = x.drop(columns=['Violations_5','Accident_Type_Code_7'])
        
    print("file preprocessing has been done ")
    return x , y


def outputfile(testdata):
    
    #creating accident_id and severity column
    submission_file = pd.DataFrame(columns=['Accident_ID','Severity'],index=None)
    
    #assinging accidentid and severity
    submission_file['Accident_ID']= testdata['Accident_ID']
    submission_file['Severity'] = y_predicted
    severity_map1 = {0:'Highly_Fatal_And_Damaging',1:'Significant_Damage_And_Serious_Injuries',2:'Minor_Damage_And_Injuries',3:'Significant_Damage_And_Fatalities'}
    submission_file['Severity'].replace(to_replace=severity_map1,inplace=True)
    
    #creating file
    submission_file.to_csv('final_submission.csv',index=False)
    print("File has been successfully created")


#defining tunning parameter
params = {
    'learning_rate' : [0.1,0.001,0.01],
    'max_depth': [3,5,7,11],
    'min_child_weight' : [1,2,3,5],
    'lamdba':[0.5,1,2,0.2,0.3],
    'gamma':[0.1,0.2,0.3],
    'scale_pos_weight' : [1,3,2,0.5],
    'objective':'multi:softmax',
    'num_class': [4],
    'subsample':[0.5,1],
    'n_estimators':[1000],
    'early_stopping_rounds':[2],
    'colsample_bytree':[0.5,0.6,0.7,0.8,0.9 ],
    'num_boost_round' :[999]
}


#defining model
classifier = xgb.XGBClassifier()

#cross calidation fold for data validation 
stf = StratifiedKFold(n_splits=5,shuffle=True,random_state=123)

#parameter tunning algo
random = RandomizedSearchCV(estimator=classifier,param_distributions=params,n_iter=10,scoring='f1_weighted',cv=stf,verbose=1)

#calling the preprocessing fucntions
x , y = preprocessing(train_dataset)


#fitting the model
random.fit(x,y)

#taking best estimators with it's parameter
algo = random.best_estimator_


#reading the test data
testdata = pd.read_csv('test.csv')

#calling preprocessing function
x_test , y_test = preprocessing(testdata)

#predicting the values for test data
y_predicted = algo.predict(x_test)

#calling submission file generation program
x = outputfile(testdata)







